import { Component, Input, OnInit } from '@angular/core';
import { City } from 'src/app/module/city';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  @Input()
  cities:City[]= [];
  constructor() { }

  ngOnInit(): void {
  }

}
