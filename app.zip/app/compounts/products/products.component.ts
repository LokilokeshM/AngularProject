import { Component, Input, OnInit } from '@angular/core';
import Product from 'src/app/module/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @Input()
  myProduct:Product[]=[];
  constructor() { }

  ngOnInit(): void {
  }

}
