import BaseClass from "./BaseModel";

export default class Product extends BaseClass{

    id:number=0;
    name:string='';
    description:string="";
    cost:number=0;
}
