import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CalculationComponent } from './components/calculation/calculation.component';
import { CustomerComponent } from './components/customer/customer.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { FraudulentPaymentComponent } from './components/fraudulent-payment/fraudulent-payment.component';
import { LoginComponent } from './components/login/login.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { PaymentComponent } from './components/payment/payment.component';
import { ProductsComponent } from './compounts/products/products.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent,
    children:[{path:'product',component:ProductsComponent},
    ]},
  {path:'calculation',component:CalculationComponent},
  {path:'payment',component:PaymentComponent},
  {path:'product',component:ProductsComponent},
  {path:'fradPayment',component:FraudulentPaymentComponent},
  {path:'customers',component:CustomerComponent},
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
