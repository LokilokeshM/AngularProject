import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GridComponent } from './compounts/grid/grid.component';
import { ProductsComponent } from './compounts/products/products.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CalculationComponent } from './components/calculation/calculation.component';
import { PaymentComponent } from './components/payment/payment.component';
import { FraudulentPaymentComponent } from './components/fraudulent-payment/fraudulent-payment.component';
import { CustomerComponent } from './components/customer/customer.component';

@NgModule({
  declarations: [
    AppComponent,
    GridComponent,
    ProductsComponent,
    LoginComponent,
    DashboardComponent,
    PagenotfoundComponent,
    SidebarComponent,
    NavbarComponent,
    CalculationComponent,
    PaymentComponent,
    FraudulentPaymentComponent,
    CustomerComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
