import { Component, OnInit } from '@angular/core';
import { CalcService } from 'src/app/service/calc.service';
import { UnitconversionService } from 'src/app/service/unitconversion.service';

@Component({
  selector: 'app-calculation',
  templateUrl: './calculation.component.html',
  styleUrls: ['./calculation.component.css']
})
export class CalculationComponent implements OnInit {
  public inr:number = 0;
  myCountries:string="";
  myOutput:any;
  myCurrency:string="";
  mySelect:string ="";
  num:number=0;
  conVal:any;
  constructor(private calc:CalcService,private conv:UnitconversionService) { }
  myFran:any;
  ngOnInit(): void {
  }
  displaySelectedDropDown(e:any)
  {
  this.myOutput='';
  this.myCurrency='';
  this.myCountries = e.target.value;
  if(this.myCountries == 'usa') {this.myOutput = this.calc.multi(this.inr,0.014).toFixed(2); this.myCurrency = 'Dollar'}; 
  if(this.myCountries == 'uk') {
  this.myCurrency = 'Pound sterling';
  this.myOutput = this.calc.multi(this.inr,0.0099).toFixed(2);
  }
  if(this.myCountries == 'singapore') {
  this.myCurrency = 'Dollar';
  this.myOutput = this.calc.multi(this.inr,0.018).toFixed(2);
  }
}

handleCalculation(a:any)
{
  this.myFran = this.conv.convertTemp(a);
}
handleConvert(a:any)
{
this.mySelect='';
this.conVal='';
this.mySelect =a.target.value;
if(this.mySelect=='m') this.conVal = this.conv.convertLength(this.num,100);
if(this.mySelect=='mm') this.conVal = this.conv.convertLength(this.num,0.001);
if(this.mySelect=='km') this.conVal = this.conv.convertLength(this.num,1000);
if(this.mySelect=='cm') this.conVal = this.conv.convertLength(this.num,.100);
}
}
