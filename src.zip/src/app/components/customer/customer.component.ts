import { Component, OnInit } from '@angular/core';
import { Customers, CustomersDetails } from 'src/app/module/customers';
import { PaymentDetails } from 'src/app/module/payment-details';
import { CustomersService } from 'src/app/service/customers.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  id:number=0;
  customerId:number=0;
  CustomerTypes:string="";
  CreditCardTypes:string="";
  Currencies:string="";
  Countries:string="";
  Cities:string="";
  payDetails:PaymentDetails[]=[];
  payDetails1:PaymentDetails[]=[];
  customers:Customers[]=[];
  accbalance:number=0;
  am:number = 0;
  climt:number =0;
  constructor(private customer:CustomersService) { }

  ngOnInit(): void {
    this.customer.getCustomers().then((cust:Customers[])=>
    {
      this.customers= cust;
    });
   
  }
  
  handleCustomerDetails(id:any){
    this.id = id.target.value;
    this.customerId=0;
    this.CustomerTypes='';
    this.CreditCardTypes='';
    this.Currencies='';
    this.Countries='';
    this.Cities='';
    this.customers.forEach((item,index)=>
    {
      if(item.customerId ==this.id)
      {
        this.CustomerTypes=item.CustomerTypes ;
        this.CreditCardTypes=item.CreditCardTypes;
        this.Currencies=item.Currencies;
        this.Countries=item.Countries;
        this.Cities=item.Cities;
      }
    })
  }

  handleRequiredCustomers(a:any)
  {
    this.payDetails=[];
    console.log(this.payDetails)
    this.customer.getAllCustomersDetails().pipe(map(data=>data.filter(d=>d.Customerid==a)),
    map(data=>data.filter(d=>d.currency=="Rupees")))
    .subscribe((data)=>{this.payDetails = data});
     
    
  }


  handleAvailbleBalance(a:any)
  {
    this.am = a.target.value;
    this.customer.getAllCustomersDetails().pipe(map(data=>data.filter(d=>d.from_Account==this.am)),
    map(data=>data.filter(d=>d.currency=="Rupees")))
    .subscribe((data)=>{this.payDetails1= data;})
    console.log(this.payDetails1);
    this.payDetails1.forEach((item,index)=>
     {
       if(item.from_Account == this.am)
       {
         this.accbalance = item.amount_limit;
         this.climt = item.bank_charges;
       }
     })
  }
}
