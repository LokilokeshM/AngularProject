import { Component, OnInit } from '@angular/core';
import { NumberValueAccessor } from '@angular/forms';
import { Router } from '@angular/router';
import { City } from 'src/app/module/city';
import Product from 'src/app/module/product';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  title = 'My Angular Day 17 Work Sheet';
  public txtName:any ="";
  public txtValue:string="";
  public MyTextEvent:string="";
  public name:string ="";
  myCity:City[]= [];
  public len:number=0;
  clickEvent:string="";
  selectedDay: string = '';

  myProducts:Product[]=[];
  
  
  myCountries:string="";
  ids:any;
  pName:string='';
  pDesc:string='';
  cost:any;
  oddCity:City[]=[];
  evenCity:City[]=[];
  selectChangeHandler (event: any) {
    this.selectedDay = event.target.value;
  }
  constructor(private router:Router)
 {
    setTimeout(() => {
      console.log("Time out is working......");
    }, 5000);
    this.myCity=[
      {id:1,cName:"Chennai",countryName:"India"},
      {id:2,cName:"Bangalore",countryName:"India"},
      {id:3,cName:"Mumbai",countryName:"India"}
    ];
    this.myProducts=[
      {id:1,name:"One Plus",description:"It is a kind of Mobile",cost:5000},
      {id:2,name:"Hp",description:"It is a kind of Laptop",cost:52000},
      {id:3,name:"Sun Glass",description:"It is a kind of Glass Model",cost:500},
    ];
  }
  getInputName1(e:any)
  {
    this.txtName = e.value;
    console.log('value....'+this.txtName);
  }
getInputName(e:string)
{
  this.clickEvent = e;
  console.log('value....'+e);
}
getTextValues(e:any)
{
console.log('Value is.....'+ e.target.value);
}

displaySelectedDropDown(e:any)
{
  this.myCountries = e.target.value;
}

handleAddProduct(p:Product)
{
  console.log(JSON.stringify(p));
  this.myProducts.push(p);
}
handleRemProd(ids:number)
{
  console.log(ids);
  this.myProducts.forEach((item,index)=>{
    if(item.id == ids)
    {
      this.myProducts.splice(index,1);
    }
  });
}
updateProduct(id:number)
{
  //console.log(id)
  this.myProducts.forEach((item,index)=>{
    if(item.id == id)
    { console.log(id)
        this.ids=item.id;
        this.pName= item.name;
        this.pDesc =item.description;
        this.cost =item.cost;
      }
     });
}
  HandleLogout()
  {
    sessionStorage.clear();
    this.router.navigate(["/login"]);
  }

  handleAddProduct1()
  {
    this.myProducts.forEach((item,index)=>{
      if(item.id == this.ids)
      { 
          item.id= this.ids;
          item.name =this.pName;
          item.description =this.pDesc ;
          item.cost =this.cost ;
        }
       });
  }
  handleFilter(a:any)
  {
    this.txtName = a.target.value;
    if(this.txtName=='even')
    {
      this.myCity.forEach((item,index)=>
        {
          if(item.id % 2 == 0)
          {
            // this.oddCity = new City(item.id,item.cName,item.countryName);
          }
        });
    }
    else
    {
      console.log("sdkfjhsdklfh");
    }
    
  }
  ngOnInit(): void {
  }
}
