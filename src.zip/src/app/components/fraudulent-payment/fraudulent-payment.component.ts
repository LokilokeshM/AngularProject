import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FraudulentPayment } from 'src/app/module/fraudulent-payment';
import { PaymentService } from 'src/app/service/payment.service';

@Component({
  selector: 'app-fraudulent-payment',
  templateUrl: './fraudulent-payment.component.html',
  styleUrls: ['./fraudulent-payment.component.css']
})
export class FraudulentPaymentComponent implements OnInit {

  sNo=0;
  fraudulentpayment:FraudulentPayment[]=[];
  constructor(private fps:PaymentService) { }

  ngOnInit(): void {
    this.fps.getfraudulent_payment().subscribe((fraudulentpayment)=>this.fraudulentpayment = fraudulentpayment)
  }

}
