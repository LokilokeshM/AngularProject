import { Component, OnInit } from '@angular/core';
import { Auth } from 'src/app/module/auth';
import {Router} from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public userName:string="";
  public password:string="";
  auth:Auth[] =[];
  constructor(private router: Router) { }

  ngOnInit(): void {

  }
  handleLogin()
  {
    let auth={
      userName:this.userName,
      password:this.password,
      ts:new Date()
    }
    sessionStorage.setItem("auth",JSON.stringify(auth));
    console.log(auth);
    this.router.navigate(['/dashboard']);
  }
}
