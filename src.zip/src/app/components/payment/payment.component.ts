import { Component, OnInit } from '@angular/core';
import { Payment } from 'src/app/module/payment';
import { PaymentService } from 'src/app/service/payment.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  payments:Payment[]=[];
  constructor(private pService:PaymentService) { }

  ngOnInit(): void {
    this.pService.getPaymentList().subscribe((payament)=>{
        this.payments =payament;
      })
  }
  addPayment()
  {
    let p:Payment;
    p={
    "id": Math.random(),
    "Customerid": 454545454,
    "payment_amount": 5467457,
    "currency": "Dollers",
    "from_Account": 7878,
    "To_Account": 878,
    "beneficiary_account": 7878,
    "bank_charges": 78787878
    }
    this.pService.addPaymentDetails(p).subscribe((bk)=>{
      console.log(bk);
      this.payments.push(p);
    });
    
  }
}
