import { Component, Input, OnInit } from '@angular/core';
import { City } from 'src/app/module/city';
import Product from 'src/app/module/product';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  @Input()
  cities:City[]= [];

  myProduct:Product[]=[];
  ids:any;
  pName:string='';
  pDesc:string='';
  cost:any;
  constructor() { }

  ngOnInit(): void {
  }
  updateProduct(ids:number)
  {
    //this.id = ids.target.value;
    console.log(ids);
    // this.myProduct.forEach((item,index)=>{
    //   if(index == ids)
    //   {
    //     this.ids=item.id;
    //     this.pName= item.name;
    //     this.pDesc =item.description;
    //     this.cost =item.cost;
    //   }
    //  });
  }
  handleAddProduct(){}
} 
