import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import Product from 'src/app/module/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @Input()
  myProduct:Product[]=[];
  
  @Output()
  public eventAddProduct:EventEmitter<Product> = new EventEmitter<Product>();

  @Output()
  public eRProd:EventEmitter<number> =new EventEmitter<number>();

  @Output()
  public eUProd:EventEmitter<number> =new EventEmitter<number>();
  
  product:Product= new Product(0,'','',0);
  constructor() { }

  ngOnInit(): void {
  }

  handleAddProduct(id:any,pName:string,pDesc:string,cost:any)
  {
    this.product= new Product(id,pName,pDesc,cost);
    console.log(JSON.stringify(this.product));
    this.eventAddProduct.emit(this.product);
  }
  handleRemProd(ids:any)
  {
    console.log(ids);
    this.eRProd.emit(ids);
  }
  handleDetailProd(ids:any)
  {
    console.log(ids);
    this.eUProd.emit(ids);
  }
}
