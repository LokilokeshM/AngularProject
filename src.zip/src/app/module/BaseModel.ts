export default abstract class BaseClass
{
    
}