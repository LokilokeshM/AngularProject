export interface Auth {
    userName:string,
    password:string,
    ts:Date;
}
