import BaseClass from './BaseModel';
export class City extends BaseClass{

    id:any;
    cName:string="";
    countryName:string="";
}
