import BaseClass from './BaseModel';
export class City extends BaseClass{

    constructor(id:any,cName:string,countryName:string)
    {
        super();
        this.id= id;
        this.cName= cName;
        this.countryName = countryName;
    }
    id:any;
    cName:string="";
    countryName:string="";
}
