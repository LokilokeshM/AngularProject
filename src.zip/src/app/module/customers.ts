export class Customers {
    customerId:number=0;
    CustomerTypes:string="";
    CreditCardTypes:string="";
    Currencies:string="";
    Countries:string="";
    Cities:string="";
}
export class CustomersDetails{
    id:number=0;
    Customerid:number=0;
    payment_amount:number=0;
    currency:string="";
    from_Account:number=0;
    To_Account:number=0;
    beneficiary_account:number=0;
    bank_charges:number=0;
    banned_currencies:string="";
    amount_limit:number=0;
    Blocked_banned_accounts:number=0;
    date_Time=new Date();
    CustomerTypes:string="";
    CreditCardTypes:string="";
    Countries:string="";
    Cities:string="";
    Application_Status:string='';
}
