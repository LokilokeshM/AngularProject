import { FraudulentPayment } from './fraudulent-payment';

describe('FraudulentPayment', () => {
  it('should create an instance', () => {
    expect(new FraudulentPayment()).toBeTruthy();
  });
});
