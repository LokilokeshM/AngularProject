export class FraudulentPayment {
    banned_currencies:string="";
    amount_limit:number=0;
    Blocked_banned_accounts:number=0;
    date_Time=new Date();
}
