import BaseClass from "./BaseModel";

export default class Product extends BaseClass{

    constructor(id:any,pName:string,pDesc:string,cost:any)
    {
        super();
        this.id=id;
        this.name=pName;
        this.description=pDesc;
        this.cost=cost;
    }
    id:any=0;
    name:string='';
    description:string="";
    cost:any=0;
}
