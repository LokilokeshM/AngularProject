import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customers, CustomersDetails } from '../module/customers';
import { PaymentDetails } from '../module/payment-details';


@Injectable({
  providedIn: 'root'
})
export class CustomersService {

  custUrl:string=" http://localhost:3000/cutomer";
  custUrl1:string=" http://localhost:3000/PaymentDetails";

  constructor(private http:HttpClient) { }

  getCustomers():Promise<Customers[]>
  {
    return this.http.get<Customers[]>(this.custUrl).toPromise(); 
  }

  getAllCustomersDetails():Observable<CustomersDetails[]>
  {
    return this.http.get<CustomersDetails[]>(this.custUrl1);
  }
}
