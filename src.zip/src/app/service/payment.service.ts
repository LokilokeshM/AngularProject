import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FraudulentPayment } from '../module/fraudulent-payment';
import { Payment } from '../module/payment';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  Url:string=" http://localhost:3000/";
  paymentUrl:string=this.Url +'payment';
  fraudulent_paymentUrl:string=this.Url +'fraudulent_payment';
  constructor(private http:HttpClient) { }

  public getPaymentList():Observable<Payment[]> 
  {
    return this.http.get<Payment[]>(this.paymentUrl);
  }
  public addPaymentDetails(p:Payment):Observable<Payment[]>
  {
    return this.http.post<Payment[]>(this.paymentUrl,p);
  }

  public getfraudulent_payment():Observable<FraudulentPayment[]>
  {
    return this.http.get<FraudulentPayment[]>(this.fraudulent_paymentUrl);
  }
  
}
