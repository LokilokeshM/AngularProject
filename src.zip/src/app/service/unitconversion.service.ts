import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UnitconversionService {

  constructor() { }
  //T = T × 1.8 + 32

  public convertTemp(a:number):number
  {
    return a*1.8 + 32 ;
  }
  public convertLength(a:number,b:number):number
  {
    return a*b;
  }
}
